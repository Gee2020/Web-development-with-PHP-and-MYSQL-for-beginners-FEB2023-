<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <div style='color:blue'>HTML TEST </div>
   <?php echo "<div style='color:red'>PHP TEST RED</div>" ?>
   
   <?php
    //variable declaration
    $name = "Jok Garcia";
    $address = "Quezon City";
    $contact_number = "+6302721212";
    $age = 65;

    //$age = 65;

    echo "Hello! " . $name . "<br>" . " age : " . $age;
   ?>

   <br>
   <br>

   <?php
   //Constant
   define("SITE_URL","https://www.tutorialrepublic.com/");
   
   // Using constant
   echo 'Thank you for visiting - ' . SITE_URL;
   ?>

   <br>
   <br>
   <?php
    echo "<h4>Order</h4>";
    
    $product = "IPhone 11";
    $price = 56000.99;
    $quantity = 2;
    $total = $price * $quantity;

    echo "<h3 style='color:green;'> Total is : Php " . $total . "</h3>";

    echo "Congrats! " . $name
   ?>

   <?php
   //Indexed Array
   $locations = array("NCR","Pampanga","Nueva Ecija","Batangas","La Union");
   
   //Associative Array
   $codes = array("Nueva Ecija"=>3,"Pampanga"=>2,"NCR"=>1);

   echo "<h4>Compare</h4>";
   
   if ($age < 60){
    echo "No Discount";
   }
   else if ($age >= 60 ){
    echo "With Discount";
   }
   //    if ($address == "Q.C"){
//     echo "Kyusinero!!";
//    }
//    else{
//     echo "Address Not Found";
//    }
   
   echo "<br>";
   echo "<h4>Shipping Fee</h4>";

   switch($locations[1]) {
    case "NCR" : {
        echo "Location " . $locations[0];
        echo " SF : PHP " . 50.99;
        echo "<br>";
        echo "Zip Code : " . $codes["NCR"];
        break;
    }
    case "Nueva Ecija" : {
        echo "Location " . $locations[2];
        echo " SF : PHP " . 90.50;
        echo "<br>";
        echo "Zip Code : " . $codes["Nueva Ecija"];
        break;
    }
    case "Pampanga" : {
        echo "Location " . $locations[1];
        echo " SF : PHP " . 85.70;
        echo "<br>";
        echo "Zip Code : " . $codes["Pampanga"];
        break;
    }
    default :
        echo "Location Not Found";
   }

   echo "<br>";
   echo "<br>";
   echo "<h4>Loops</h4>";

   $index = 0;
   $size = sizeof($locations) - 1;
   
   echo "<h5>While</h5>";
   while($index <= $size){
    echo "Location " . $locations[$index];
    echo "<br>";
    $index++;
   }

   echo "<h5>For Loop</h5>";
   for($index = 0; $index <= $size; $index++){
    echo "Location " . $locations[$index];
    echo "<br>";
   }

   echo "<h5>For Each</h5>";
   foreach($locations as $value ){
    echo "Location " . $value . "<br>";
   }

   ?>
</body>
</html>